Vue.component('list', {
    props: {

    },

    methods: {

    },

    template: '',

    computed: {

    }
});